"""Isi otomatis nama perpustakaan & alamat yang KOSONG di Excel, dari daftar Word.
Hanya mengisi sel kosong; data yang sudah ada tidak pernah ditimpa.
Dry-run:  python isi_otomatis.py
"""
import re, difflib
from docx import Document
from openpyxl import load_workbook

SKIP_SHEETS = {"TBM", "PERPUS KECKEL"}
SD_SECTION = {"SD PTK UTARA": "UTARA", "SD PTK TIMUR": "TIMUR", "SD PTK SELATAN": "SELATAN",
              "SD PTK TENGGARA": "TENGGARA", "SD PTK BARAT": "BARAT", "SD PTK KOTA": "KOTA"}
ACRONYM = {"SD", "SDN", "SMP", "SMPN", "SMPIT", "SDI", "SDIT", "SMPS", "LKIA", "PGRI", "YPK", "TBM", "IT"}
ROMAN = re.compile(r"^[IVX]+$")


def smart_title(s):
    def fix(m):
        t = m.group(0)
        return t.upper() if t.upper() in ACRONYM or ROMAN.match(t.upper()) else t.capitalize()
    return re.sub(r"\s+", " ", re.sub(r"[A-Za-z0-9’']+", fix, s.strip()))


def norm(s):
    s = str(s).lower().replace("’", "'")
    s = re.sub(r"smpit\b", "smp it", s)
    s = re.sub(r"sdit\b", "sd it", s)
    s = s.replace("islam terpadu", "it").replace("'", "")
    s = re.sub(r"[^a-z0-9 ]", " ", s)
    return " ".join(t for t in s.split() if t not in {"kota", "kecamatan", "pontianak"})


def is_smp(name):
    return bool(re.search(r"\b(smp|smpit|smps|smpn|mts)\b", name.lower()))


def clean(t):
    return re.sub(r"\s+", " ", t.replace("\xa0", " ")).strip()


def parse_docx(path):
    out, section = [], ""
    for table in Document(path).tables:
        for row in table.rows:
            cells = []
            for c in row.cells:  # sel gabungan terbaca berulang -> buang duplikat berurutan
                t = clean(c.text)
                if not cells or cells[-1] != t:
                    cells.append(t)
            if len(cells) <= 2 and cells and cells[0].upper().startswith(("KECAMATAN", "SMP")):
                section = cells[0].upper()
            elif len(cells) >= 4 and cells[0].isdigit():
                out.append({"section": section, "school": cells[1], "library": cells[2], "address": cells[3]})
    return out

def parse_xlsx(path):
    """Daftar versi Excel: kolom No, Jenjang, Kecamatan, Nama Sekolah, Nama Perpustakaan, Alamat."""
    ws, out = load_workbook(path).active, []
    for r in ws.iter_rows(min_row=2, values_only=True):
        jenjang, kec, school, lib, adr = [clean(str(v)) if v is not None else "" for v in r[1:6]]
        if not school or school.upper() in ("SMP NEGERI", "SMP SWASTA"):  # baris judul yang nyasar
            continue
        section = "SMP" if jenjang.upper() == "SMP" else "KECAMATAN " + kec.upper()
        out.append({"section": section, "school": school, "library": lib, "address": adr})
    return out


def parse_daftar(path):
    return parse_xlsx(path) if path.lower().endswith(".xlsx") else parse_docx(path)

def score(a, b):
    na, nb = norm(a), norm(b)
    if re.findall(r"\d+", na) != re.findall(r"\d+", nb):
        return 0.0
    return difflib.SequenceMatcher(None, na, nb).ratio()


def pool_for(sheet, name, docs):
    if is_smp(name):
        return [d for d in docs if d["section"].startswith("SMP")]
    sec = SD_SECTION.get(sheet)
    return [d for d in docs if sec and d["section"].endswith(sec)] if sec else []


def plan(xlsx, docx):
    docs, wb, out = parse_daftar(docx), load_workbook(xlsx), []
    for ws in wb:
        if ws.title in SKIP_SHEETS:
            continue
        for r in range(4, ws.max_row + 1):
            name = ws.cell(r, 2).value
            if not name or re.match(r"(kelurahan|kecamatan)\b", str(name).strip().lower()):
                continue
            name = str(name).strip()
            lib, adr = (ws.cell(r, 3).value or "").strip(), (ws.cell(r, 4).value or "").strip()
            if lib and adr:
                continue
            cands = [(score(name, d["school"]), d) for d in pool_for(ws.title, name, docs)]
            best_s, best = max(cands, key=lambda x: x[0], default=(0, None))
            item = {"sheet": ws.title, "row": r, "name": name, "match": None, "score": round(best_s, 2), "fields": {}}
            if best and best_s >= 0.6:
                item["match"] = best["school"]
                if not lib and best["library"]:
                    item["fields"]["library"] = smart_title(best["library"])
                if not adr and best["address"]:
                    item["fields"]["address"] = best["address"]
            out.append(item)
    return out


def apply(xlsx_path, items):
    """Isi sel kosong sesuai items hasil plan(); kembalikan (workbook, jumlah_sel_terisi)."""
    wb, n = load_workbook(xlsx_path), 0
    for it in items:
        ws = wb[it["sheet"]]
        for field, col in (("library", 3), ("address", 4)):
            if field in it["fields"] and not (ws.cell(it["row"], col).value or "").strip():
                ws.cell(it["row"], col).value = it["fields"][field]
                n += 1
    return wb, n


if __name__ == "__main__":
    for it in plan("data/CEKLIS_IPLM.xlsx", "data/DAFTAR_PERPUS_SD_DAN_SMP.docx"):
        print(it["sheet"], it["row"], "|", it["name"], "->", it["match"], it["score"], it["fields"])
