"""Rekap status IPLM + ekspor Excel."""
from io import BytesIO
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from isi_otomatis import norm

KEYS = ("sudah", "belum_lengkap", "belum_mengisi")
LABEL = {"sudah": "Sudah Mengisi", "belum_lengkap": "Belum Lengkap", "belum_mengisi": "Belum Mengisi"}


def hitung(entries):
    rows = []
    for sheet, items in entries.items():
        c = {k: 0 for k in KEYS}
        c["kosong"] = 0
        for i in items:
            c[i["status"] or "kosong"] += 1
        rows.append({"sheet": sheet, "total": len(items), **c})
    total = {k: sum(r[k] for r in rows) for k in ("total", *KEYS, "kosong")}
    return rows, total


def duplikat(entries):
    seen = {}
    for sheet, items in entries.items():
        for i in items:
            seen.setdefault(norm(i["name"]), []).append({"sheet": sheet, "name": i["name"], "status": i["status"]})
    out = []
    for g in seen.values():
        if len({x["sheet"] for x in g}) > 1:
            out.append({"name": g[0]["name"], "items": g, "konflik": len({x["status"] for x in g}) > 1})
    return out


def buat_xlsx(entries, user):
    rows, _ = hitung(entries)
    wb = Workbook()
    ws = wb.active
    ws.title = "Rekap"
    f, fb = Font(name="Arial", size=10), Font(name="Arial", size=10, bold=True)
    head = PatternFill("solid", fgColor="D9E2F3")
    thin = Side(style="thin", color="999999")
    box = Border(left=thin, right=thin, top=thin, bottom=thin)
    ws["A1"] = "REKAP PENGISIAN IPLM"; ws["A1"].font = Font(name="Arial", size=13, bold=True)
    ws["A2"] = f"Dibuat {datetime.now():%d/%m/%Y %H:%M} oleh {user}. Jumlah per status diambil dari tools; total dan persen dihitung rumus."
    ws["A2"].font = Font(name="Arial", size=9, italic=True)
    for j, h in enumerate(["Sheet", "Total", "Sudah Mengisi", "Belum Lengkap", "Belum Mengisi", "% Sudah"], 1):
        c = ws.cell(4, j, h); c.font, c.fill, c.border = fb, head, box
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    r0 = 5
    for n, r in enumerate(rows):
        i = r0 + n
        ws.cell(i, 1, r["sheet"]); ws.cell(i, 2, f"=SUM(C{i}:E{i})")
        ws.cell(i, 3, r["sudah"]); ws.cell(i, 4, r["belum_lengkap"]); ws.cell(i, 5, r["belum_mengisi"])
        ws.cell(i, 6, f"=IF(B{i}=0,0,C{i}/B{i})")
    last, t = r0 + len(rows) - 1, r0 + len(rows)
    ws.cell(t, 1, "TOTAL (jumlah baris, semua sheet)")
    for j, col in enumerate("BCDE", 2):
        ws.cell(t, j, f"=SUM({col}{r0}:{col}{last})")
    ws.cell(t, 6, f"=IF(B{t}=0,0,C{t}/B{t})")
    for i in range(r0, t + 1):
        for j in range(1, 7):
            c = ws.cell(i, j); c.font = fb if i == t else f; c.border = box
            if j == 6: c.number_format = "0.0%"
    for j, w in zip("ABCDEF", (36, 10, 14, 14, 14, 10)):
        ws.column_dimensions[j].width = w
    ws.cell(t + 2, 1, "Catatan: sekolah yang tercatat di lebih dari satu sheet terhitung di tiap sheet.").font = Font(name="Arial", size=9, italic=True)

    tl = wb.create_sheet("Tindak Lanjut")
    for j, h in enumerate(["Sheet", "Nama", "Nama Perpustakaan", "Alamat", "Status"], 1):
        c = tl.cell(1, j, h); c.font, c.fill, c.border = fb, head, box
    n = 2
    for st in ("belum_mengisi", "belum_lengkap"):
        for sheet, items in entries.items():
            for i in items:
                if i["status"] == st:
                    for j, v in enumerate([sheet, i["name"], i["library"], i["address"], LABEL[st]], 1):
                        c = tl.cell(n, j, v); c.font, c.border = f, box
                    n += 1
    for j, w in zip("ABCDE", (22, 42, 46, 44, 16)):
        tl.column_dimensions[j].width = w
    tl.freeze_panes = "A2"
    bio = BytesIO(); wb.save(bio); bio.seek(0)
    return bio
