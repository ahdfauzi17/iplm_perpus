"""
Tools Pengisian IPLM untuk staf perpustakaan.
Membaca & menulis langsung ke data/CEKLIS_IPLM.xlsx.

Jalankan:  python app.py   lalu buka http://localhost:5000
"""
import os, csv, shutil, threading, secrets, time
from datetime import datetime, timedelta
from functools import wraps
from flask import Flask, jsonify, render_template, request, session, redirect, send_file
from copy import copy
from openpyxl import load_workbook
from openpyxl.styles import Font
from openpyxl.styles.colors import Color
import auth, isi_otomatis, rekap

BASE = os.path.dirname(os.path.abspath(__file__))
XLSX = os.path.join(BASE, "data", "CEKLIS_IPLM.xlsx")
DOCX = os.path.join(BASE, "data", "DAFTAR_PERPUS_SD_DAN_SMP.xlsx")  # daftar acuan (xlsx; kalau tidak ada pakai docx)
if not os.path.exists(DOCX):
    DOCX = os.path.join(BASE, "data", "DAFTAR_PERPUS_SD_DAN_SMP.docx")
BACKUP_DIR = os.path.join(BASE, "backup")
LOG = os.path.join(BASE, "log_perubahan.csv")
SECRET = os.path.join(BASE, "secret.key")

# Kolom status (Sudah, Belum Lengkap, Belum Mengisi) per sheet; default E,F,G.
STATUS_COLS = {"TBM": (4, 5, 6), "PERPUS KECKEL": (3, 4, 5)}
DEFAULT_COLS = (5, 6, 7)
KEYS = ("sudah", "belum_lengkap", "belum_mengisi")
LABEL = rekap.LABEL
FIRST_ROW = 4


# Warna TRUE sesuai Excel asli: hijau (Sudah), oranye (Belum Lengkap), merah (Belum Mengisi)
STATUS_FONT = {
    "sudah": Font(name="Arial", size=10, color=Color(theme=7)),
    "belum_lengkap": Font(name="Arial", size=10, color="FFE69138"),
    "belum_mengisi": Font(name="Arial", size=10, color="FFFF0000"),
}
# Kolom keterangan (Ket): H untuk sheet biasa, G untuk TBM, None = tidak ada
NOTE_COL = {"TBM": 7, "PERPUS KECKEL": None}
DEFAULT_NOTE_COL = 8

app = Flask(__name__)
app.json.sort_keys = False  # urutan tab = urutan sheet di Excel
app.config.update(SESSION_COOKIE_SAMESITE="Lax", SESSION_COOKIE_HTTPONLY=True,
                  PERMANENT_SESSION_LIFETIME=timedelta(hours=12))
lock = threading.Lock()  # cegah dua staf menyimpan bersamaan


def _secret():
    if not os.path.exists(SECRET):
        with open(SECRET, "w") as f:
            f.write(secrets.token_hex(32))
    return open(SECRET).read().strip()


app.secret_key = _secret()
FAILS = {}  # (ip, user) -> (jumlah, waktu pertama)


# ---------- helper Excel ----------
def cols_for(sheet):
    return STATUS_COLS.get(sheet, DEFAULT_COLS)


def is_total_row(ws, r, cols):
    
    v = ws.cell(r, cols[0]).value
    return isinstance(v, str) and v.startswith("=")
def note_col(sheet):
    return NOTE_COL.get(sheet, DEFAULT_NOTE_COL)


def read_entries():
    wb = load_workbook(XLSX)
    out = {}
    for ws in wb:
        cols = cols_for(ws.title)
        items = []
        for r in range(FIRST_ROW, ws.max_row + 1):
            name = ws.cell(r, 2).value
            if not name or not str(name).strip() or is_total_row(ws, r, cols):
                continue
            status = None
            for k, c in zip(KEYS, cols):
                if ws.cell(r, c).value is True:
                    status = k
            if ws.title == "TBM":
                lib, addr = "", f"Kel. {ws.cell(r, 3).value or '-'}"
            elif ws.title == "PERPUS KECKEL":
                lib, addr = "", ""
            else:
                lib = (ws.cell(r, 3).value or "").strip()
                addr = (ws.cell(r, 4).value or "").strip()
                nc = note_col(ws.title)
            ket = (str(ws.cell(r, nc).value).strip() if ws.cell(r, nc).value else "") if nc else None
            items.append({"row": r, "name": str(name).strip(), "library": lib,
                          "address": addr, "status": status, "ket": ket})
        out[ws.title] = items
    return out


def backup_harian():
    os.makedirs(BACKUP_DIR, exist_ok=True)
    bk = os.path.join(BACKUP_DIR, f"CEKLIS_IPLM_{datetime.now():%Y%m%d}.xlsx")
    if not os.path.exists(bk):
        shutil.copy2(XLSX, bk)


def simpan(wb):
    wb.calculation.fullCalcOnLoad = True  # total COUNTIF dihitung ulang saat dibuka
    tmp = XLSX + ".tmp"
    wb.save(tmp)
    try:
        os.replace(tmp, XLSX)
    except PermissionError:
        os.remove(tmp)
        raise


def catat(user, sheet, row, name, lama, baru, ket=""):
    baru_file = not os.path.exists(LOG)
    with open(LOG, "a", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        if baru_file:
            w.writerow(["waktu", "user", "sheet", "baris", "nama", "dari", "menjadi", "keterangan"])
        w.writerow([f"{datetime.now():%Y-%m-%d %H:%M:%S}", user, sheet, row, name, lama, baru, ket])


# ---------- auth ----------
def current_user():
    u = session.get("u")
    return auth.get(u) if u else None


def guard(admin=False):
    def deco(f):
        @wraps(f)
        def w(*a, **k):
            u = current_user()
            if not u:
                return jsonify(error="Silakan login dulu"), 401
            if admin and u["role"] != "admin":
                return jsonify(error="Khusus admin"), 403
            if request.method == "POST" and request.headers.get("X-Requested-With") != "iplm":
                return jsonify(error="Permintaan ditolak"), 400
            return f(u, *a, **k)
        return w
    return deco


@app.errorhandler(PermissionError)
def file_terkunci(_):
    return jsonify(error="File Excel sedang dibuka di aplikasi lain. Tutup dulu, lalu coba lagi."), 423


@app.get("/login")
def login_page():
    return render_template("login.html")


@app.post("/api/login")
def api_login():
    if request.headers.get("X-Requested-With") != "iplm":
        return jsonify(error="Permintaan ditolak"), 400
    b = request.get_json(force=True)
    uname = str(b.get("username", "")).strip().lower()
    key = (request.remote_addr, uname)
    n, t0 = FAILS.get(key, (0, time.time()))
    if n >= 5 and time.time() - t0 < 300:
        return jsonify(error="Terlalu banyak percobaan. Coba lagi 5 menit lagi."), 429
    if n >= 5:
        n, t0 = 0, time.time()
    u = auth.verify(uname, str(b.get("password", "")))
    if not u:
        FAILS[key] = (n + 1, t0)
        return jsonify(error="Username atau password salah"), 401
    FAILS.pop(key, None)
    session.clear(); session["u"] = u["username"]; session.permanent = True
    return jsonify(u)


@app.post("/api/logout")
def api_logout():
    session.clear()
    return jsonify(ok=True)


@app.get("/api/me")
@guard()
def api_me(u):
    return jsonify(u)


@app.post("/api/ganti-password")
@guard()
def api_ganti_password(u):
    b = request.get_json(force=True)
    if not auth.verify(u["username"], str(b.get("lama", ""))):
        return jsonify(error="Password lama salah"), 400
    try:
        auth.set_password(u["username"], str(b.get("baru", "")))
    except ValueError:
        return jsonify(error="Password baru minimal 6 karakter"), 400
    return jsonify(ok=True)


# ---------- halaman & data ----------
@app.get("/")
def index():
    if not current_user():
        return redirect("/login")
    return render_template("index.html")


@app.get("/api/data")
@guard()
def api_data(u):
    with lock:
        return jsonify(read_entries())


@app.post("/api/save")
@guard()
def api_save(u):
    body = request.get_json(force=True)
    sheet, row, status = body.get("sheet"), int(body.get("row", 0)), body.get("status")
    if status not in KEYS:
        return jsonify(error="Status tidak valid"), 400
    with lock:
        wb = load_workbook(XLSX)
        if sheet not in wb.sheetnames:
            return jsonify(error="Sheet tidak ditemukan"), 400
        ws = wb[sheet]
        cols = cols_for(sheet)
        if row < FIRST_ROW or not ws.cell(row, 2).value or is_total_row(ws, row, cols):
            return jsonify(error="Baris tidak valid"), 400
        lama = next((LABEL[k] for k, c in zip(KEYS, cols) if ws.cell(row, c).value is True), "(kosong)")
        backup_harian()
        for k, c in zip(KEYS, cols):
            cell = ws.cell(row, c)
            cell.value = True if k == status else None
            cell.font = copy(STATUS_FONT[k])  # warna kolom selalu benar
        simpan(wb)
        catat(u["username"], sheet, row, str(ws.cell(row, 2).value).strip(), lama, LABEL[status])
    return jsonify(ok=True)



@app.post("/api/ket")
@guard()
def api_ket(u):
    body = request.get_json(force=True)
    sheet, row, ket = body.get("sheet"), int(body.get("row", 0)), str(body.get("ket", "")).strip()[:1000]
    with lock:
        wb = load_workbook(XLSX)
        if sheet not in wb.sheetnames or not note_col(sheet):
            return jsonify(error="Sheet ini tidak punya kolom keterangan"), 400
        ws = wb[sheet]
        if row < FIRST_ROW or not ws.cell(row, 2).value or is_total_row(ws, row, cols_for(sheet)):
            return jsonify(error="Baris tidak valid"), 400
        cell = ws.cell(row, note_col(sheet))
        lama = str(cell.value or "")
        if lama == ket:
            return jsonify(ok=True)
        backup_harian()
        cell.value = ket or None
        if cell.font.name != "Arial":
            cell.font = Font(name="Arial", size=10)
        simpan(wb)
        catat(u["username"], sheet, row, str(ws.cell(row, 2).value).strip(), "", "", "keterangan: " + (ket or "(dikosongkan)"))
    return jsonify(ok=True)


# ---------- rekap ----------
@app.get("/api/rekap")
@guard()
def api_rekap(u):
    with lock:
        entries = read_entries()
    rows, total = rekap.hitung(entries)
    return jsonify(rows=rows, total=total, duplikat=rekap.duplikat(entries))


@app.get("/api/rekap.xlsx")
@guard()
def api_rekap_xlsx(u):
    with lock:
        entries = read_entries()
    return send_file(rekap.buat_xlsx(entries, u["nama"]), as_attachment=True,
                     download_name=f"Rekap_IPLM_{datetime.now():%Y%m%d_%H%M}.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


# ---------- isi otomatis (admin) ----------
@app.get("/api/isi-otomatis")
@guard(admin=True)
def api_isi_preview(u):
    with lock:
        return jsonify(isi_otomatis.plan(XLSX, DOCX))


@app.post("/api/isi-otomatis")
@guard(admin=True)
def api_isi_apply(u):
    pilih = {(x["sheet"], int(x["row"])) for x in request.get_json(force=True).get("items", [])}
    with lock:
        items = [i for i in isi_otomatis.plan(XLSX, DOCX) if (i["sheet"], i["row"]) in pilih and i["fields"]]
        if not items:
            return jsonify(error="Tidak ada data yang bisa diisi"), 400
        backup_harian()
        wb, n = isi_otomatis.apply(XLSX, items)
        simpan(wb)
        for i in items:
            catat(u["username"], i["sheet"], i["row"], i["name"], "", "",
                  "isi otomatis: " + ", ".join(i["fields"]))
    return jsonify(ok=True, sel_terisi=n, baris=len(items))


# ---------- riwayat (admin) ----------
@app.get("/api/riwayat")
@guard(admin=True)
def api_riwayat(u):
    if not os.path.exists(LOG):
        return jsonify([])
    with open(LOG, encoding="utf-8-sig", newline="") as f:
        return jsonify(list(csv.DictReader(f))[-300:][::-1])


if __name__ == "__main__":
    pw = auth.ensure_admin()
    if pw:
        print("=" * 52, "\nAkun admin pertama dibuat.\n  username: admin\n  password:", pw,
              "\nCatat sekarang; password ini tidak ditampilkan lagi.\n" + "=" * 52)
    app.run(host="0.0.0.0", port=5000, debug=False)
