"""Pengelolaan akun (users.json, password di-hash)."""
import json, os, secrets
from werkzeug.security import generate_password_hash, check_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))
USERS = os.path.join(BASE, "users.json")
ROLES = ("admin", "staf")


def _load():
    if not os.path.exists(USERS):
        return {}
    with open(USERS, encoding="utf-8") as f:
        return json.load(f)


def _save(d):
    tmp = USERS + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=2, ensure_ascii=False)
    os.replace(tmp, USERS)


def get(username):
    u = _load().get(username)
    return {"username": username, "nama": u.get("nama", username), "role": u["role"]} if u else None


def add(username, password, role="staf", nama=None):
    d = _load()
    username = username.strip().lower()
    if not username or role not in ROLES or len(password) < 6:
        raise ValueError("Username kosong, role tidak valid, atau password < 6 karakter")
    d[username] = {"hash": generate_password_hash(password), "role": role, "nama": nama or username}
    _save(d)


def delete(username):
    d = _load()
    if username not in d:
        raise ValueError("User tidak ditemukan")
    if d[username]["role"] == "admin" and sum(1 for x in d.values() if x["role"] == "admin") == 1:
        raise ValueError("Tidak bisa menghapus admin terakhir")
    del d[username]
    _save(d)


def verify(username, password):
    u = _load().get(username.strip().lower())
    if u and check_password_hash(u["hash"], password):
        return get(username.strip().lower())
    return None


def set_password(username, password):
    d = _load()
    if username not in d or len(password) < 6:
        raise ValueError("User tidak ada atau password < 6 karakter")
    d[username]["hash"] = generate_password_hash(password)
    _save(d)


def listing():
    return [{"username": k, "nama": v.get("nama", k), "role": v["role"]} for k, v in _load().items()]


def ensure_admin():
    """Buat admin pertama dengan password acak bila belum ada akun. Kembalikan password-nya (sekali saja)."""
    if _load():
        return None
    pw = secrets.token_urlsafe(8)
    add("admin", pw, "admin", "Administrator")
    return pw
