# Tools Pengisian IPLM

Aplikasi web lokal untuk staf perpustakaan. Klik status sebuah sekolah/TBM/kelurahan,
dan centang langsung tersimpan ke `data/CEKLIS_IPLM.xlsx` (Sudah / Belum Lengkap / Belum Mengisi).

## Menjalankan
1. Python 3.10+, lalu `pip install -r requirements.txt`
2. `python app.py`
3. Pada jalankan PERTAMA, terminal menampilkan password akun `admin` (acak, hanya muncul sekali).
4. Buka http://localhost:5000  (staf lain di jaringan kantor: http://IP-KOMPUTER:5000)

## Akun
Kelola lewat terminal:
    python kelola_user.py tambah budi            # staf
    python kelola_user.py tambah sari --admin    # admin
    python kelola_user.py reset budi             # ganti password
    python kelola_user.py hapus budi
    python kelola_user.py daftar
Setiap user bisa ganti password sendiri lewat tombol "Ganti password".
Password disimpan ter-hash di `users.json`. 5x salah login = dikunci 5 menit.

## Fitur
- **Pengisian** (semua user): pilih sheet, cari, filter status, klik untuk mencentang.
- **Rekap** (semua user): total per sheet + progres, daftar entri ganda antar sheet,
  dan tombol unduh Excel (sheet "Rekap" + "Tindak Lanjut" berisi yang belum mengisi/belum lengkap).
- **Isi Otomatis** (admin): isi nama perpustakaan/alamat yang KOSONG dari file Word.
  Ada pratinjau + skor kecocokan; data yang sudah ada tidak pernah ditimpa.
  Dry-run via terminal: `python isi_otomatis.py`
- **Riwayat** (admin): siapa mengubah apa dan kapan (`log_perubahan.csv`).

## Catatan
- Tutup file Excel saat tools dipakai (Excel mengunci file terbuka); jika masih terbuka, tools menampilkan pesan.
- Cadangan harian otomatis di `backup/`.
- Jangan bagikan `users.json` dan `secret.key`.
- Koneksi memakai HTTP biasa; pakai hanya di jaringan kantor tepercaya.

## Struktur
app.py (backend) · auth.py (akun) · rekap.py (rekap & ekspor) · isi_otomatis.py (pencocokan Word)
kelola_user.py (CLI akun) · templates/ (antarmuka) · data/ (Excel & Word)
