"""Kelola akun lewat terminal.
  python kelola_user.py daftar
  python kelola_user.py tambah budi            (staf)
  python kelola_user.py tambah sari --admin
  python kelola_user.py reset budi
  python kelola_user.py hapus budi
"""
import sys, getpass
import auth

def pw():
    a, b = getpass.getpass("Password: "), getpass.getpass("Ulangi  : ")
    if a != b:
        sys.exit("Password tidak sama.")
    return a

args = sys.argv[1:]
if not args:
    sys.exit(__doc__)
cmd = args[0]
try:
    if cmd == "daftar":
        for u in auth.listing():
            print(f"{u['username']:15} {u['role']:6} {u['nama']}")
    elif cmd == "tambah":
        auth.add(args[1], pw(), "admin" if "--admin" in args else "staf"); print("User ditambahkan.")
    elif cmd == "reset":
        auth.set_password(args[1], pw()); print("Password diganti.")
    elif cmd == "hapus":
        auth.delete(args[1]); print("User dihapus.")
    else:
        sys.exit(__doc__)
except (ValueError, IndexError) as e:
    sys.exit(f"Gagal: {e}")
